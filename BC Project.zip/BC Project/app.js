var mysql = require('mysql');
var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var path = require('path');
let alert = require('alert');
var url=require('url');
const { response } = require('express');
const { request } = require('http');
const res = require('express/lib/response');
var path = require('path');
const Web3 = require('web3');
var web3 = new Web3('http://localhost:8545')
var urlencodedParser = bodyParser.urlencoded({extended:true});
var username
var con=mysql.createConnection({
    host:'localhost',
    user:'root',
    password:'',
    database:'BC Project'
})


app.use(bodyParser.urlencoded({extended : true}));
app.use(bodyParser.json());
app.set('view engine', 'ejs');


app.get('/login',(req,res) =>{
    res.sendFile(path.join(__dirname+'/login.html'))
})


app.get('/account:id',(req,res)=>{
    username = req.params.id;
    username = username.substring(1)
    // res.send(username)
    con.query('select l.* from Lands l,users u where l.Uid = u.Uid and u.username = ?',[username],(err,result)=>{
        // res.send(result)
        var length = (result.length)
        res.render('account',{resultss : result,len : length,usernames:username})

    })
})

app.post('/home',(req,res)=>{
    username = req.body.username
    password = req.body.password

    con.query('select * from users where username = ?',[username],(err,results)=>{
        if(username == 'admin')
        {
            con.query('select u.username,l.* from Lands l ,users u where u.Uid = l.Uid',[results[0].Uid],(err,result)=>{
                var length = (result.length)
                res.render('admin',{resultss : result,len : length,usernames:username})
            })
        }
        else
        {
            if(password == results[0].password)
            { 
                console.log('Valid Authentication')
                con.query('select u.username,l.* from Lands l ,users u where l.Uid != ? and Available="yes" and u.Uid = l.Uid',[results[0].Uid],(err,result)=>{
                    var length = (result.length)
                    res.render('home',{resultss : result,len : length,usernames:username})
                })
            }
            else
            {
                alert('Invalid Credentials')
                res.redirect('/login')
            }
        }
    })

})


app.post('/buy',(req,res)=>{
    uid = req.body.vari
    username = req.body.usernames
    amount = req.body.amount
    Lid = req.body.Lid
    reciever_address = ''
    con.query('select Acc_address from users where Uid = "'+uid+'"',(err,result)=>{
        reciever_address = result[0].Acc_address
        // res.send(uid + username + amount + reciever_address)
        con.query('select Acc_address,Uid from users where username = "'+username+'"',(err,results)=>{
            sender_address = results[0].Acc_address
            // web3.eth.personal.unlockAccount(reciever_address,"123",6000)
            web3.eth.sendTransaction({
                    from: sender_address,
                    gasPrice: "20000000000",
                    gas: "21000",
                    to: reciever_address,
                    value: amount,
                    data: ""
                }, 'node1').once('transactionHash', function(hash)
                    { 
                    // setTimeout(function(){
                            // localStorage.setItem('thash',hash);
                        // console.log(hash); 
                    // },5000)
                        
                    });
                    console.log(results[0].Uid+' '+Lid)
                con.query('update Lands set Uid = ? where Lid = ?',[results[0].Uid,Lid],(err,ress)=>{
                    console.log(ress.affectedRows)
                    // res.send('Transaction of '+amount+' is done')
                    // res.write('<h1>Transaction is Successful and property has been transferred successfully</h1>')
                    alert('Transaction is Successful and property has been transferred successfully')
                    // res.sendFile(path.join(__dirname+'/temp.html'))
                    res.redirect('/login')
                })
                con.commit()
            // res.send(uid + username + amount + reciever_address + sender_address)

        })

    })
    // res.send(uid+amount)
    
})


app.get('/',(req,res)=>{
    res.redirect('/login')
})

app.listen(4000);